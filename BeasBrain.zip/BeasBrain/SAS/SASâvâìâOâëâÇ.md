back to [[SAS]]
## SASプログラム
-   SASプログラムはDATAステップやPROCステップやDATAステップとPROCステップの任意の組み合わせで構成できます。
-   SASステートメント（DATA、SET、RUN、その他）はSASキーワードで始まり、必ずセミコロンで終わる。
-   フリー・フォーマット
-   空白や特殊文字はSASステートメントのワードを区切ります。大文字でも小文字でもSASステートメントを指定できます。ほとんどの場合、引用符で囲まれたテキストは、大文字小文字を区別します。
### DATAステップ
- 通常SASデータセットを作成または編集します。また、独自のレポートを作成するためにも使用できます。
	```sas
	data sasuser.admit2;
	  set sasuser.admin;
	  where age>39;
	  label data='Departure Date';
	  format date date9.;
	run;
	```
### PROC（プロシジャ）ステップ
- SASデータセットのデータを分析し処理することのできる、あらかじめ準備されたルーチンを起動したり、呼び出したりします。
#### 出力形式
##### 1.[[リストレポートの作成#リストレポート作成|プロシジャの出力]]
- 形式をリストか、HTMLかに指定することができる（Preferenceで設定）
	```sas
	proc print data=sasuser.admit2;
	run;
	```
##### 2.対話レポート・ウィンドウ
- データを直接変更するために使用するウィンドウ
	```sas
	proc report data=sasuser.admit;
	  columns id name sex age actlevel;
	run;
	```
##### 3.Tabulateプロシジャ
 ```sas
proc tabulate data=sasuser.admit; 
  class sex; 
  var height weight; 
  table sex*(height weight),mean; 
run;
```
##### 4.ログのみの出力
```sas
proc copy in=sasuser out=work;
  select admin;
run;
```
### 編集
- 拡張エディタの利用
	- テキストの色分け、次の行を自動的にインデント、折りたたみや展開、コードの行のブックマーク、マクロの記録、独自のキーワードの作成と書式の設定
	- **省略形**
		- 利用：文字列を入力してタブキーまたはEnterキーを押すと、その文字列がさらに長い文字列に展開される
		- 作成：Tool > Abbreviation
	-  **複数のファイルのビューを開く**
		-  そのファイルをアクティブ・ウィンドウにして、Window > New Windowを選択する（1つビューでの変更を同時に反映される）
	-  **拡張エディタのオプションの設定**
		-  Tool > Option > Enhanced Editor（行番号の表示などを設定できる）
	-  **プログラムエディタ**
		-  行番号：_**nums**_
    		-   SASセッションの間だけ表示されている。
    		-   永久的に行番号を表示するために、Tool > Option > Program Editorで設定できる
		-   テキストエディタの行コマンド
			-   テキストエディタの行コマンドによって、テキストの削除、挿入、移動、コピー、繰り返しができる。
    		-   _**Cn,Dn,In,Mn,Rn,A,B**_
		-   ブロック・テキストエディタ行コマンド
    		-   _**DD,CC,MM,RR,A,B**_
		-   SASプログラムのリコール
			-   SASステートメントはサブミットする際にプログラムエディタ・ウィンドウから消去されます。しかし、「実行」＞「最後のサブミットをリコール」を選択して、プログラムエディタへプログラムをリコールすることができる。
	- **拡張エディタのエラーチェック**
		- Ctrl+]で終了の角括弧や丸括弧
		- Alt+\[でDO-ENDペアをマッチさせる
### デバッグ
- DATAステップの論理的エラーをデバッグすることができる
- デバッガは対話モードでのみ使用することができる
- ```sas
	data perm.publish / debug;
	  infile pubdata;
	  input BookID $ Publisher & $22. Year;
	run;
	proc print data=perm.publish;run;
	```