back to [[SASプログラム]]
## リストレポート作成
#### 変数の選択
- _**VAR**_ variables(s);
	- 1つまたはそれ以上の空白で区切られた変数名
- OBS列の削除
	- _**NOOBS**_オプション

#### オブザベーションの識別
- IDステートメント
	- _**ID**_ variables(s);
	- レポートの各行の最初に、オブザベーション番号の代わりに印字する1つ以上の変数を指定する
	- オブザベーションが1行で印字するには長すぎる場合に特に便利
- オブザベーションの選択
	- _**WHERE**_ where-expression;
	- 複数のWHEREステートメントが発行されると、最後のステートメントのみが処理される
	- **比較演算子**：=/eq, ^=/ne, >/gt, </lt, >=/ge, <=/le
	- **CONTANTS演算子**：CONTAINS/?（指定した部分文字列を含むオブザベーションを選択する）
	
#### データの並べ替え
- _**PROC SORT DATA=(SAS-data-set) <OUT=(SAS-data-set>;BY BY-variable(s);RUN**_;

#### 列合計の生成
- _**SUM**_ variables(s);
	- レポートの最後に表示される
	- BYステートメント
		- _**BY (DESCENDING) BY-variable-1 (... BY-variable-n) (NOTSORTED);**_
		- 2つ以上の変数がある場合、DESCENDINGはすぐ後の変数にだけ適用される
		- _**NOTSORTED**_オプション
			- BY変数の同じ値を持っているオブザベーションが連続していないならば、プロシジャは各連続しているセットを別々のBYグループとして扱う
- **BYグループとID変数でのカスタム・レイアウトの作成**
	- ID、BY、SUMを同時に使用する。IDステートメントにBYステートメントと同じ変数を指定する。
- **別ページでの小計の要求**
	- _**PAGEBY**_ BY-variable;
	- 指定される変数は、PROC PRINTステップのBYステートメントにも指定されていなければなりません
#### ダブルスペース・リスト出力
- _**DOUBLE**_オプション
- ダブルスペース（行間に空白行を入れる）
- HTML出力には適用されません
#### タイトルとフットノートの指定
- _**TITLE/FOOTNOTE**_ 'text';
- 使用すると、プロシジャ出力に最大10個のタイトル・フットノートを関連付けることができる
- どこにでも記述できる。デフォルトのタイトルは「SASシステム」、フットノートは指定されるまで印字されない
- TITLESおよびFOOTNOTESウィンドウの利用
	- TITLESコマンド・FOOTNOTESコマンドを発行して指定する
	- 現SASセッションの間のみ効果を持続する
- 編集と取り消し
	- 再定義すると、すべてのより大きい番号のタイトルやフットノートをそれぞれ取り消す（すべて取り消すには「_**title;**_」か「_**title1;**_」、「_**footnote;**_」か「_**footnote1;**_」を指定する）
	```sas
	title1 'Heart Rates for Patients with';
	title3 'Increased Stress Tolerance Levels';
	footnote1 'Data from Treadmill Tests';
	proc sort data=clinic.admit out=work.wgtadmit;
	  by descending weight age;  
	run;
	proc print data=work.wgtadmit double;
	  var age height weight fee;
	  where (firstname ? 'Jon' and ID>'1050') or fee in (124.80,178.20);
	  sum fee;
	  by actlevel;
	  id actlevel;
	  pageby actlevel;
	run;
	```
#### 説明的なラベルの割り当て（一時的に）
- _**LABEL**_ _variable1='label1' variable2='label2' ...;_
- PROCステップにだけ適用される
#### データ値のフォーマット化（一時的に）
- _**FORMAT**_ _variable(s) format-name;_
- PROCステップにだけ適用される
	```sas
	proc print data=clinic.therapy label;
	  label walkjogrun='Walk/Jog/Run' 
	        height='Height in Inches';
	  format fee dollar4.;
	  format net comma5.0 gross comma8.2;
	  format net gross dollar9.2;
	run;
	```
#### 永久的に割り当てられるラベルと出力形式
- [[SASプログラム#DATAステップ|DATAステップ]]で割り当てる
#### その他の機能
- ラベルのテキスト文字の区切り位置の制御
	- _**SPLIT**_オプション
	```sas
	proc print data=reps split='*';
	  var salesrep type unitsold net commisiion;
	  label salesrep='Sales*Representative';
	run;
	```
- 独自の出力形式の作成
	```sas
	proc format;
	  value $repfmt 'TFB'='Bynum' 'MDC'='Crowley' 'WKK'='King';
	run;
	proc print data=vcrsales;
	  var salesrep type unitsold;
	  format salesrep $repfmt.;
	run;
	```