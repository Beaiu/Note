back to [[SAS]]
## SASライブラリ
SASファイルをさん参照する前に、ファイルが保存されるライブラリに名前を割り当てなければなりません。
***
### タイプ
1. #### 一時
ファイル作成する際にライブラリ名を指定しない時（あるいはworkを指定）、セッション終了時、一時ライブラリとそのすべてのファイルは削除される。
2. #### 永久
Work以外のライブラリ名を指定。デフォルトライブラリ(Sashelp, Sasuser, Work)
***
### LIBNAMEステートメント
_**LIBNAME libref (engine) ‘SAS-data-library’;**_
- ==libref==: 1文字から8文字で、アルファベットかアンダースコアから初め、アルファベット、数字、アンダースコアだけを含みます
- ==(engine)==: 他の形式のファイルの参照（SASファイルだけでなく他のソフトウェア・プロダクトで作成されたファイルも参照することができる。その時、SASが自動的に適したエンジンを選択するものがありますが、どのエンジンを使用するのか伝える必要があるものもあります）
  - インターフェイス・ライブラリ・エンジン：BMDP, OSIRIS, SPSS
  - SAS/ACCESSエンジン：お使いのサイトにSAS/ACCESSソフトウェアがライセンスされていれば、LIBNAMEステートメントを使用してDBMSファイルに保存されているデータにアクセスすることができます。
- **有効時間**：現在のSASセッションの間のみ（SASエクスプローラから新規ライブラリ・ウィンドウを使用して作成されるライブラリは、「起動時に有効」を選択すると起動時に自動的に割り当てることができる）
	```sas            
	libname recipe 'c:\Users\...';
	data recipe.yakisoba1;
		set recipe.yakisoba0;
	run;
	```
***
### ライブラリコンテンツの表示
#### 1. PROC CONTENTSの利用
_**PROC CONTENTS DATA=SAS-file-specification NODS;RUN;**_
==NODS==は_ALL_を指定する場合に各ファイルについての詳細情報の印字を省略します（_ALL_を指定する場合のみNODSを指定できます）
```sas      
proc contents data=clinic._all_ nods;
run;
```
Option > varnum [[#VARNUMオプションの指定]]

#### 2. PROC DATASETSの利用
SASファイルのコピー、削除、修正などの多くの管理タスクを実行することができる。
_**PROC DATASETS; CONTENTS; QUIT;**_
```sas
proc datasets;
contents data=clinic._all_ nods;
quit;
```
Option > varnum [[#VARNUMオプションの指定]]

#### * VARNUMオプションの指定
[[#1 PROC CONTENTSの利用]]と[[#2 PROC DATASETSの利用]]に利用でき、変数一覧表示をアルファベット順の代わりに、データセットの論理的な場所の順（作成順）に変数名を列記する。
```sas
proc contens data=sasuser.admit varnum; run;

proc datasets;
  contents data=sasuser.admit varnum;
quit;
```