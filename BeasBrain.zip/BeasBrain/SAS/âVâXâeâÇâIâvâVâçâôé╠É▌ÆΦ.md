back to [[SAS]]
## システムオプションの設定
- **OPTION**ステートメントでそれ以降の設定を変更できる。SASセッションを終えるまで有効。
- System Option Windowからも設定できる（Tool > Option > System)（セッションの終了まで有効）
### DATE|NODATE, NUMBER|NONUMBER
- ページ番号と日付の出力（デフォルトで表示される）
  ```sas
  ods listing;
  options nonumber nodate;
  proc print data=sasuser.diabetes;
    var id sex age height weight;
    where age>=30;
  run;
  ods listing close;
  ```
### PAGENO
- ページ番号を印字する場合、リストレポートの開始ページ番号を指定することができる
- 指定しない場合、出力はSASセッションを通して1ページから連続的に数字が付けられる
  ```sas
  ods listing;
  options number pageno=3;
  proc print data=hrd.funddrive;
  run;
  ods listing close;
  ```
### PAGESIZE（別名PS=）
- 各ページに何行含めるかを指定する
### LINESIZE（別名LS=）
- 印字ライン幅を指定する。ラインサイズに入らないオブザベーションは次の行に続けられる。
### YEARCUTOFF
- 2桁の年の扱い：2000年問題。どの100年の期間が使用されるのかを指定する（デフォルト=1920）。
- SASは1582年~20000年までの日付を正確に表す。
  ```sas
  options yearcutoff=1925;
  ```
### FIRST / OBS
- FIRSTOBS=に対して処理する最初のオブザベーション番号を指定する（デフォルトは1）
- OBS=に対して処理する最後のオブザベーションの番号を指定する（デフォルトはMAX、お使いのオペレーティング環境で表せる最大の8バイトの符号付き整数）
- システム・オプション或いはデータセット・オプションとして指定できる
  ```sas
  /* システム・オプションとして指定*/
  options firstobs=10 obs=15;
  proc print data=clinic.heart;
  run;
  
  /* データセット・オプションとして指定*/
  proc print data=clinic.heart(firstobs=10 obs=15);
  run;
  ```

### 追加機能
- FORMCHAR = 'formatting-characters'
- FORMDLIM = delimit=character'
- LABEL | NOLABEL
- REPLACE | NOREPLACE
- SOURCE | NOSOURCE
- ERRORS
- FMTERR | NOFMTERR
- SOURCE | NOSOURCE