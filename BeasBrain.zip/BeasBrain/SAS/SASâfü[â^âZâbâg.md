back to [[SAS]]
## SASデータセット
### 名前のルール
- 1から32文字の長さ
- アルファベット（A-Zの大文字または小文字）かアンダースコアで開始しなければならい
- 数字、またはアルファベット、またはアンダースコアの任意の組合わせを続けることができる

### データセットの部分
- **ディスクリプタ部**：データセット属性、変数属性
- **データ部**：変数（列）、オブザベーション（行）
- **インデックス**

### 外部ファイルからのSASデータセットの作成
1. SASデータライブラリの参照：_**[[SASライブラリ#LIBNAMEステートメント|LIBNAME]]**_
2. 外部ファイルの参照：_**FILENANME**_
	- _**FILENAME**_ _fileref 'filename';_
	- ファイル名だけではなく、複数の外部ファイルを含むディレクトリなどの保存場所をファイル参照名に関連付けることもできる
	- 参照されているファイルの詳細を表示するには「ファイルショートカット」
		```sas
		filename tests 'c:\users\tmill.dat';
		```
3. データセットの命名：_**[[SASプログラム#DATAステップ|DATA]]**_
4. 外部ファイルの識別：_**INFILE**_
	- _**INFILE**_ _file-specification (options);_
		```sas
		data clinic.therapy;
			infile exercise;
			input Name $ City $ Age Sex Height;
		run;
		```
	- 保存場所内のファイルの参照
		```sas
		data clinic.therapy;
			infile tax(refund.dat);
			input Name $ Dept $ Site $;
		run;
		```
5. データの記述：_**INPUT**_
	- _**INPUT**_ _variable <$> startcol-endcol...;_
		- ＄は文字としての変数タイプを指定する（変数が数値ならば、ここに何も指定しない）
	-   データは標準文字値か標準数値でなければなりません（他の入力はフォーマット入力などを利用）
		-   非標準データ
			-   %、$、カンマ（,）などを含む
			-   日付や時間値
			-   分数、整数の2進数、実数の2進数、16進数形式のデータ
	-   データは固定長フィールドでなければなりません（固定長フィールドでない場合、リスト入力を利用）
	-   DATAステップは無効なデータの結果であっても失敗せず、実行を継続する（ログのNOTEで確認できる）
		```sas
		filename exer 'c:\users\exer.dat';
		data exercise;
		  infile exer;
		  input ID $ 1-4 Age 6-7 ActLevel $ 9-12 Sex $ 14;
		run;
		```
1. DATAステップの実行：_**RUN**_
2. データのリスト：_**[[リストレポートの作成#リストレポート作成|PROC PRINT]]**_
3. 最終プログラム・ステップの実行：_**RUN**_