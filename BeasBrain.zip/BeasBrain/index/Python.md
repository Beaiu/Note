# Python
## Python入門
- dictionary
	```python
	# 生成
	me ={'height':100}
	# 確認 ⇒ 180
	me['height']
	# 追加
	me['weight']=70
	# 確認 ⇒ 'height':180, 'weight':70
	print(me)
	```
- class
	```python
	class classname:
		# constructor
		def __init__(self, parameter1, parameter2, ...):
			...
		def method1(self, parameter1, ...):
			...
		def method2(self, parameter2, ...):
			...
	```
	- example
	```python
	class Man:
	    def __init__(self, name):
		    self.name = name
			print("initialized!")
			
		def hello(self):
		    print("Helo"+self.name+"!")
			
		def goodbye(self):
		    print("Good-bye"+self.name+"!")
	
	m = Man("David")
	m.hello()
	m.goodbye()
	# ⇒ Initialized!
	    Hello David!
		Good-bye David!
	```
- Library
	- [[Numpy]]