## Numpy基礎
```python
import numpy as np

# 配列の作成1
a = np.array([1.0, 2.0, 3.0])
# 配列の作成2
b = np.array([1,2],[3,4])
b.shape    # ⇒ (2,2)
b.dtype    # ⇒ (dtype('int64'))

# 配列の確認
X = np.array([[51,55],[14,19],[0,4]])
# 方法1
X[0]    # ⇒ [51,55]
X[0][1]    # ⇒ 55
# 方法2
for row in X:
    print(row)    # ⇒ [51,55],[14,19],[0,4]
# 方法3
X = X.flatten()
print(X)    # ⇒ [51 55 14 19 0 4]
X[np.arrary([0,2,4])]    # ⇒ [51,14,0]
X[X>15]    # ⇒ [51,55,19]
```